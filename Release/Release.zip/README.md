# Direseeker

[![](https://cdn.discordapp.com/attachments/469291841859092488/784510230054436904/unknown.png)]()

[![](https://cdn.discordapp.com/attachments/750033133604175982/784501239014228030/unknown.png)]()

[![](https://cdn.discordapp.com/attachments/755556626681036881/791955506314477568/texDireseekerIcon.png)]()

## Overview

Replaces the legendary chest in Abyssal Depths with a unique AWU-tier superboss, Direseeker. To summon it, there are several buttons placed around the map. Pressing 4 of these buttons will summon the Direseeker.

[![](https://cdn.discordapp.com/attachments/469291841859092488/785976744171012106/unknown.png)]()

Direseeker is a massive Elder Lemurian with devastating fiery attacks. Killing it should be faster than AWU, but the risk is far greater as it's an offensive powerhouse.

The intent is to make Abyssal Depths a more viable stage for multiplayer, providing a red item for each player like AWU does.

## Installation

Place the EnforcerGang-Direseeker folder in BepInEx/Plugins.
I recommend just using R2Modman to install the mod.

## Known Issues
- Boss health bar doesn't show up for clients

## Credits

- Moffein: Rebuilt mod for SotV.
- Rob: Original mod.
- JunJun_w: Chinese translation
- Damglador: Ukrainian translation
- Адский Шкед, lecarde: Russian translation
- StyleMyk: French translation