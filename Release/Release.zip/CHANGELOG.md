`2.0.0`
- Added custom SFX to everything
- Added roar VFX
- Flamebreath radius increased
- Enrage now activates at 40% health
- Enrage function reworked: now grants way more CDR, a permanent massive armor buff, health slowly decays until death, all entities around it are constantly burned and it emits constant magma balls until death
- Flame Pillar area indicator updated

`1.5.1`

- Ungrabbable bodyflag.

`1.5.0`
- fixed for MemOp
- made fireballs actually come from his mouth
- lowered his feet to the floor

`1.4.8`

- Fixed for latest update.

`1.4.7`

- Fixed overlays?

`1.4.6`

- Fixed nullrefs on Enrage and Flame Pillar.

`1.4.5`

- Skillstates now keep track of their own deltaTime to mitigate the effects of framerate-dependent gameplay. (unsure if it works)
- Fixed Enrage skill permanently locking Direseeker.

`1.4.4`

- Updated for DLC2 (Untested)
- Increased mass from 300 to 900 to be on par with other bosses.

`1.4.3`

- Updated RU TL (Thanks lecarde!)

`1.4.2`

- Added FR TL (Thanks StyleMyk!)

`1.4.1`

- Updated BR TL

`1.4.0`

- Fixed buttons not showing up for clients in multiplayer.

`1.3.10`

- Updated BR TL.

`1.3.9`

- Updated AccurateEnemies compat. Now is affected by AccurateEnemies config options.

`1.3.7`

- Added Russian translation from Адский Шкед

`1.3.6`

- Updated Ukrainian translation.

`1.3.5`

- Added Ukrainian translation from Damglador.

`1.3.4`

- AccurateEnemies compatibility.

`1.3.3`

- Added Chinese translation (Thanks Edge-R!)

`1.3.2`

- Attempted to fix boss healthbar not showing up in multiplayer.

`1.3.1`

- Fixed a minor console error when loading the mod.

`1.3.0`

- Rebuilt the mod based on the decompiled source code of the previous version.
	- Old sounds were lost, so the mod will be re-using various sounds from Vanilla in the meantime.

`1.2.2`
- Fixed to work on latest RoR2 version

`1.2.1`
- Fixed to work on latest RoR2 version

`1.2.0`
- Added custom sounds
- Nerfed fireball damage a little bit more
- Doubled flame pillar damage and amount of blasts
- Enrage duration increased from 3s to 5s
- Now gains bonus armor during enragement
- Fixed enragement buffs being applied multiple times in multiplayer
- Changed fire trails to a proper fire texture rather than a generic explosion(1.1.0 change that I forgot to list)

`1.1.0`
- Added a new attack
- Added rage mode(triggers below 20% hp)
- Nerfed fireball damage to compensate for the new loadout
- Flamebreath now guarantees an ignite proc on every hit
- Updated icon

`1.0.1`
- Made Direseeker immune to stuns
- Added 2 extra buttons
- Tweaked spawn animation to add some more oomph
- Fixed missing flame effect

`1.0.0`
- Initial release